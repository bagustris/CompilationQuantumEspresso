# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/SubSec:propedit/;
$ref_files{$key} = "$dir".q|developer_man.html|; 
$noresave{$key} = "$nosave";

$key = q/SubSec:Bugs/;
$ref_files{$key} = "$dir".q|developer_man.html|; 
$noresave{$key} = "$nosave";

$key = q/SubSec:Inst/;
$ref_files{$key} = "$dir".q|developer_man.html|; 
$noresave{$key} = "$nosave";

$key = q/SubSec:CPP/;
$ref_files{$key} = "$dir".q|developer_man.html|; 
$noresave{$key} = "$nosave";

$key = q/SubSec:Merge/;
$ref_files{$key} = "$dir".q|developer_man.html|; 
$noresave{$key} = "$nosave";

$key = q/Sec:SVN/;
$ref_files{$key} = "$dir".q|developer_man.html|; 
$noresave{$key} = "$nosave";

$key = q/SubSec:conf/;
$ref_files{$key} = "$dir".q|developer_man.html|; 
$noresave{$key} = "$nosave";

$key = q/SubSec:Conflicts/;
$ref_files{$key} = "$dir".q|developer_man.html|; 
$noresave{$key} = "$nosave";

1;

